#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Kai
#
# Created:     23/11/2013
# Copyright:   (c) Kai 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------

def main():
    pass

if __name__ == '__main__':
    main()

import random
from Tkinter import *
import numpy as np

class Character(object):#obtained from invaders "physObject" class, modified
    def __init__(self,x,y,dx,dy,girth,color): #right now, missing loyalty
        self.x=x
        self.y=y
        self.dx=dx
        self.dy=dy
        self.girth=girth
        self.color=color
        self.exists=True

    def draw(self, canvas):
        canvas.create_rectangle(self.x,self.y,self.x+self.girth,
            self.y+self.girth,fill=self.color,outline=self.color)

    def move(self):
        self.x+=self.dx
        self.y+=self.dy


    def collides(self, other):
        if self.x-other.x<girth or self.y-other.y<girth:
            return True
        else:
            return False

class Hero(Character):
    def __init__(self,width,height):
        super(Hero,self).__init__(0,height-20,0,0,20,"white")

    def draw(self,canvas):
        canvas.create_oval(self.x,self.y-self.girth/2,self.x+self.girth,
            self.y+self.girth/2,fill=self.color,outline=self.color)
        canvas.create_rectangle(self.x,self.y,self.x+self.girth,
            self.y+self.girth,fill=self.color,outline=self.color)

    def move(self, width,height):
        super(Hero, self).move()
        if self.x < 0:
            self.x = 0
            self.dx = 0
        if self.x+self.girth > width:
            self.x = width-self.girth
            self.dx = 0
        if self.y-self.girth/2<0:
            self.y=self.girth/2
            self.dy=0
        if self.y+self.girth>height:
            self.y=height-self.girth
            self.dy=0

class Minion(Character):
    def __init__(self):
        super(Minion,self).__init__(0,0,0,0,20,"yellow")

    def move():
        #is supposed to follow the previous minion
            #does this by looking at the dx, dy of the minion in the list before
            #it. if there is none, it will follow self.me.dx and self.me.dy



class Game(object):#obtained from invaders example in class, then modified
    def __init__(self, width, height):
        self.width=width
        self.height=height
        self.me=Hero(width,height)
        self.minions=[]
        self.team=[]
        self.attacks=[]
        self.minions.append(Minion())

    def timerFired(self):
        # Move everybody
        self.me.move(self.width,self.height)
        #Add friction to the equation
        if self.me.dx>0:
            self.me.dx-=1
        if self.me.dy>0:
            self.me.dy-=1
        if self.me.dx<0:
            self.me.dx+=1
        if self.me.dy<0:
            self.me.dy+=1



        """for bullet in self.bullets:
            bullet.move()
        for enemy in self.enemies:
            enemy.move(self.width)

        # Add new invaders
        if random.uniform(0.0, 1.0) < 0.05:
            self.enemies.append(Invader())

        # Check for collisions
        for bullet in self.bullets:
            for enemy in self.enemies:
                if bullet.collides(enemy):
                    bullet.exists = False
                    enemy.exists = False
        self.bullets = [b for b in self.bullets if b.exists]
        self.enemies = [e for e in self.enemies if e.exists]
        """
        self.redrawAll()
        self.canvas.after(100, self.timerFired)

    def keyPressed(self, event):
        if event.keysym == "Left":
            if self.me.dx>-100:#caps the max speed
                if self.me.dx>-20:#sets initial speed
                    self.me.dx=-20
                else:
                    self.me.dx-=1
        elif event.keysym == "Right":
            if self.me.dx<100:#caps the max speed
                if self.me.dx<20:
                    self.me.dx=20 #sets initial speed
                else:
                    self.me.dx += 1
        if event.keysym == "Up":
            if self.me.dy>-100:#caps the max speed
                if self.me.dy>-20:
                    self.me.dy=-20 #sets initial speed
                else:
                    self.me.dy -= 1
        elif event.keysym == "Down":
            if self.me.dy<100:#caps the max speed
                if self.me.dy<20:
                    self.me.dy=20 #sets initial speed
                else:
                    self.me.dy += 1
        elif event.keysym == "space":
                self.me.dx,self.me.dy=0,0

    def redrawAll(self):
        self.canvas.delete(ALL)
        self.canvas.create_rectangle(0,0,self.width,self.height,fill="light green",outline="light green")
        self.me.draw(self.canvas)
        for minion in self.minions:
            minion.draw(self.canvas)

        """for bullet in self.bullets:
            bullet.draw(self.canvas)
        for enemy in self.enemies:
            enemy.draw(self.canvas)"""

    def run(self):
        root = Tk()
        self.canvas = Canvas(root, width=self.width, height=self.height)
        self.canvas.pack()
        root.bind("<Key>", self.keyPressed)
        self.timerFired()
        root.mainloop()

game=Game(1000,600)
game.run()