#-------------------------------------------------------------------------------
# Name:        module2
# Purpose:
#
# Author:      Kai
#
# Created:     22/11/2013
# Copyright:   (c) Kai 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------

def main():
    pass

if __name__ == '__main__':
    main()


mapmap=dict()

landkey=["sand","grass","rock"]
for x in xrange(0,0+len(landkey)):
    mapmap[x]=landkey[x]
myteam=["me","friend1","friend2","friend3","friend4","friend5","etc"]
for x in xrange(100,100+len(myteam)):
    mapmap[x]=myteam[x-100]
