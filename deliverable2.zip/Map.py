#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Kai
#
# Created:     22/11/2013
# Copyright:   (c) Kai 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------

def main():
    pass

if __name__ == '__main__':
    main()

import random
from Tkinter import *
import numpy as np

class Game(object):#from cs.cmu.edu/~112
    # Override these methods when creating your own animation

    def mousePressed(self, event): pass
    def keyPressed(self, event): pass
    def timerFired(self): pass
    def init(self): pass
    def redrawAll(self): pass

    # Call app.run(width,height) to get your app started
    def run(self, width=300, height=300):
        # create the root and the canvas
        root = Tk()
        self.width = width
        self.height = height
        self.canvas = Canvas(root, width=width, height=height)
        self.canvas.pack()
        # set up events
        def redrawAllWrapper():
            self.canvas.delete(ALL)
            self.redrawAll()
        def mousePressedWrapper(event):
            self.mousePressed(event)
            redrawAllWrapper()
        def keyPressedWrapper(event):
            self.keyPressed(event)
            redrawAllWrapper()
        root.bind("<Button-1>", mousePressedWrapper)
        root.bind("<Key>", keyPressedWrapper)
        # set up timerFired events
        self.timerFiredDelay = 250 # milliseconds
        def timerFiredWrapper():
            self.timerFired()
            redrawAllWrapper()
            # pause, then call timerFired again
            self.canvas.after(self.timerFiredDelay, timerFiredWrapper)
        # init and get timerFired running
        self.init()
        timerFiredWrapper()
        # and launch the app
        root.mainloop()  # This call BLOCKS
        #(so your program waits until you close the window!)

class Map(Game):#modified from cs.cmu.edu/~112
    def __init__(self,rows=100,cols=100,cellSize=15):
        self.rows=rows
        self.cols=cols
        self.cellSize=cellSize
        self.boardMargin=40
        self.cellMargin=0
        self.cellBackgroundColor="light green"
        self.board=np.zeros((rows,cols),dtype=int)

    def redrawAll(self):
        self.drawBoard()

    def drawBoard(self):
        for row in xrange(self.rows):
            for col in xrange(self.cols):
                self.drawCell(row, col)

    def drawCell(self, row, col):
        (x0, y0, x1, y1) = self.getCellBounds(row, col)
        self.canvas.create_rectangle(x0,y0,x1,y1,
                fill="light green",outline="light green")
        self.drawCellContents(row, col, self.getCellContentsBounds(row, col))
        #self.drawCellContents(row, col, self.getCellContentsBounds(row, col))

    def drawCellContents(self, row, col, bounds):
        if self.board[row][col]==100:
            self.drawHero(bounds)


    def getCellBounds(self, row, col):
        (boardX0, boardY0, boardX1, boardY1) = self.getBoardBounds()
        cellX0 = boardX0 + col*self.cellSize
        cellX1 = cellX0 + self.cellSize
        cellY0 = boardY0 + row*self.cellSize
        cellY1 = cellY0 + self.cellSize
        return (cellX0, cellY0, cellX1, cellY1)

    def getCellContentsBounds(self, row, col):
        (cellX0, cellY0, cellX1, cellY1) = self.getCellBounds(row, col)
        cm = self.cellMargin
        return (cellX0+cm, cellY0+cm, cellX1-cm, cellY1-cm)

    def getBoardBounds(self):
        boardX0 = self.boardMargin
        boardX1 = self.width - self.boardMargin
        boardY0 = self.boardMargin
        boardY1 = self.height - self.boardMargin
        return (boardX0, boardY0, boardX1, boardY1)

    def drawHero(self,bounds):
        left,top,right,bottom=bounds
        left,top,right,bottom=float(left),float(top),float(right),float(bottom)
        width,height=right-left,bottom-top
        self.canvas.create_oval(left+width/4,top,right-width/4,
            bottom-width/2,fill="white",outline="white")
        self.canvas.create_rectangle(left+width/4,top+width/4,
            right-width/4,bottom,fill="white",outline="white")

    def run(self):
        width = self.cols*self.cellSize + 2*self.boardMargin
        height = ((self.rows * self.cellSize+ 2*self.boardMargin))
        super(Map, self).run(width, height)



#########################################################################

class MapTest(Map):
    def __init__(self, rows, cols, cellSize):
        super(MapTest, self).__init__(rows, cols, cellSize)
        self.board[rows/2][cols/2] = 100
        self.board[2][2] = 0
        self.board[3][3] = 0

if (__name__ == "__main__"):
    game = MapTest(20,20,30)
    game.run()