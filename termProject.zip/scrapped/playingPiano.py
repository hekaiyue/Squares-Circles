from Tkinter import*
import pyaudio
import wave
import sys

filename = "hello"
filename1 = "track1.wav"
def job1():
    chunk = 1024
    wf = wave.open(filename1, 'rb')
    p = pyaudio.PyAudio()
    # open audio file
    s = p.open(format =p.get_format_from_width(wf.getsampwidth()),
    channels = wf.getnchannels(),
    rate = wf.getframerate(),
    output = True)

# read
    data = wf.readframes(chunk)

# play
    while data != '':
        s.write(data)
        data = wf.readframes(chunk)

    s.close()
    p.terminate()

def job2():
    chunk = 1024
    wf = wave.open(filename1, 'rb')
    p = pyaudio.PyAudio()
    # open audio file
    s = p.open(format =
    p.get_format_from_width(wf.getsampwidth()),
    channels = wf.getnchannels(),
    rate = wf.getframerate(),
    output = True)

# read
    data = wf.readframes(chunk)

# play
    while data != '':
        s.write(data)
        data = wf.readframes(chunk)

    s.close()
    p.terminate()


root=Tk()
button1=Button(root,text="push",command=job1)
button2=Button(root,text="push",command=job2)

button1.pack()
button2.pack()
root.mainloop()