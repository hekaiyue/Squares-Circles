#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Kai
#
# Created:     19/11/2013
# Copyright:   (c) Kai 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------

def main():
    pass

if __name__ == '__main__':
    main()


from beatDetection import SimpleBeatDetection
class detectMusicBeat(SimpleBeatDetection):
    def __init__(self,beat):
        self.beat=beat

    def printDetectMusic(self):
        print detect_beat("track1.WAV")
detectMusicBeat.detect_beat("track1.WAV")

