import cv2

def runWebcam():
    #original webcam code, obtained from cbarker.net/opencv, was able to access
    #webcam. modified by Kai to periodically save a screenshot and save to file
    window_name = "Webcam"
    cam_index = 0 # Default camera is at index 0.
    cv2.namedWindow(window_name, cv2.CV_WINDOW_AUTOSIZE)
    cap = cv2.VideoCapture(cam_index) # Video capture object
    cap.open(cam_index) # Enable the camera
    counter=0
    while True:
        ret, frame = cap.read()
        if frame is not None:
            cv2.imshow(window_name, frame)
        k = cv2.waitKey(1) & 0xFF
        if k == 32:#can respond to keypress now
            print "Hello"
        if k == 27: # Escape key is the only way to close
            cv2.destroyAllWindows()
            cap.release()
            break

def image_grab_gtk(window):#image_grab_gtk obtained from stackoverflow
#currently not working yet, but almost
    left, top, right, bot = get_rect(window)
    w = right - left
    h = bot - top

    s = gtk.gdk.Pixbuf(
        gtk.gdk.COLORSPACE_RGB, False, 8, w, h)

    s.get_from_drawable(
        gtk.gdk.get_default_root_window(),
        gtk.gdk.colormap_get_system(),
        left, top, 0, 0, w, h )

    final = Image.frombuffer(
        "RGB",
        (w, h),
        s.get_pixels(),
        "raw",
        "RGB",
        s.get_rowstride(), 1)
    return final #cv2.namedWindow(window_name, cv2.CV_WINDOW_AUTOSIZE)

runWebcam()
